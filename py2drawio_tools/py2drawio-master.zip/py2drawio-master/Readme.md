v0.1
# py2drawio
This is a simple script that parses python files in a directory and generates a mxfile containing a diagramm of classes, attributes and methods which can be opened and edited using [Draw.io](drawio-app.com).

## Use
``python py2drawio.py C:/path/to/my/repo/``

## ToDo
* Add types of attributes
* Add return types of methods
* Render relationships between classes